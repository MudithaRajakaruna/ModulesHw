package lk.ijse.app;

public class SecurityConfig {
}
