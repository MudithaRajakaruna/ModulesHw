module lk.ijse.sms{
    requires com.netflix.spring_security;
    requires com.netflix.zuul;
    requires com.netflix.ribbon;
}