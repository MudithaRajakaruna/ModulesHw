package com.netflix.spring_security.config;

import com.netflix.spring_security.util.*;

public class WebSecurityConfig {
    Intercepter intercepter;
    PostAuth postAuth;

}
