package com.netflix.zuul.Service;
import com.netflix.zuul.util.*;

public class ApiGateway {
    Utility utility;
    Viz viz;
    TCPConfig tcpConfig;
}
