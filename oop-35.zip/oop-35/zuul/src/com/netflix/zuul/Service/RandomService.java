package com.netflix.zuul.Service;

public class RandomService {
}
