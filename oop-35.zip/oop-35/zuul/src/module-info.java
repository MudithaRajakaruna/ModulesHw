module com.netflix.zuul{
    exports com.netflix.zuul.Service;
    requires com.netflix.ribbon;
}